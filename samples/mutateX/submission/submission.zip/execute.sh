mkdir -p out
cp src/mutate.txt out/mutateX.txt