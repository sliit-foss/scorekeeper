## Task

Append and `X` to the end of the filename of the `mutate.txt` inside the `src` directory and copy it over to the `out` directory.

### Constraints

The script must be purely written in bash.

### Output

A single file in a directory named `out`
