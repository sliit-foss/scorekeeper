mkdir -p out
cp src/mutate.txt out/mutateY.txt